//creating a URL object
const new_url = new URL('http://www.example.com/example.html?name=example');
//logging the URL object
//print the hostname
console.log(new_url.hostname);
//print the pathname
console.log(new_url.pathname);